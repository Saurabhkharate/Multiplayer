package com.jsp.multiplayer.main;
import java.util.Scanner;
import com.jsp.multiplayercasestudy.operations.Operations;

public class MusicPlayer
{
	static Scanner sc1=new Scanner(System.in);

	public static void main(String[] args) {
		while (true) {
			
		
		
		System.out.println("=========MENU=========\n"
		                    +"1.Add Or Remove Song\n"
				            +"2.Play Song\n"
		                    +"3.Edit Song\n"
				            +"4.Exit");
      int choice=sc1.nextInt();
      if (choice==1) {
    	  System.out.println("=========MENU=========\n"
		                    +"1.Add Song\n"
				            +"2.Remove Song\n"
				            +"3.Exit");
    	  int choice1=sc1.nextInt();
    	   
			
		
    	  switch (choice1) {
		case 1:
			Operations.addSongs();
			break;
		case 2:
			Operations.removeSong();
			break;
		case 3:
			
			break;
			

		default:
			System.out.println("Enter Correct input");
			break;
		}
    	  
		
	}
      else if (choice==2) {
    	  System.out.println("=========MENU=========\n"
		                    +"1.Play All Songs\n"
				            +"2.Choose Song\n"
				            +"3.Shuffle Songs\n"
				            +"4.Exit");
    	  int choice2=sc1.nextInt();
    	  switch (choice2) {
		case 1:
			Operations.playSongs();
			
			break;
        case 2:
        	Operations.chooseSongToPlay();
			
			break;
        case 3:
        	Operations.shuffleSong();
			break;
        case 4:
			
			break;

		default:
			System.out.println("Enter Correct Number");
			break;
		}
		
	}
      else if (choice==3) {
    	  System.out.println("Enter Song Number To Edit...");
    	  Operations.editSong();
		
	}
      else if(choice==4) {
    	  System.out.println("Thank You\n"
    			  +"You have exited");
    	  break;
      }
	
      else {
    	  
		System.out.println("Enter Correct Number");
	}
		}
	}

}
