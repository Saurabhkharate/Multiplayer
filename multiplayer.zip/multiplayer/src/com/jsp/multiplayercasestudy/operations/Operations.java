package com.jsp.multiplayercasestudy.operations;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.jsp.multiplayercasestudy.entity.*;
public class Operations {
	static Scanner sc=new Scanner(System.in);
	static int choice;
	private static List <Songs>playlist=new ArrayList<Songs>();
	private static Songs songs;
	public static void displayAllSongs() {
		for (int i = 0; i < playlist.size(); i++) {
			System.out.println(i + 1 + "."+ playlist.get(i).getName());
			
			
		}
		
	}
	
	public static void addSongs() {
		System.out.println("enter the how many songs want to add");
		choice=sc.nextInt();
		for (int i=0;i<choice;i++) {
			songs=new Songs();
			System.out.println("Enter Song Name");
			String name=sc.nextLine();
			songs.setName(name);
			
			System.out.println("Enter Song ID");
			int id=sc.nextInt();
			songs.setId(id);
			
			System.out.println("Enter Music album Name");
			String mName=sc.nextLine();
			songs.setMusicAlbum(mName);
			
			System.out.println("Enter Duration of Song");
			double duration=sc.nextDouble();
			songs.setDuration(duration);
			
			System.out.println("Enter Singer Name");
			String sName=sc.nextLine();
			songs.setSinger(sName);
			
			
		playlist.add(songs);
		System.out.println(name + "Song Successfully added");
		}
}
	public static void removeSong() {
		System.out.println("=======Menu======");
		displayAllSongs();
		System.out.println("Enter Song number to be Removed.. ");
		choice = sc.nextInt();
		playlist.remove(choice-1);
		
	}
	public static void playSongs() {
		System.out.println("All Songs are playing now");
		displayAllSongs();
		
	}
	public static void chooseSongToPlay() {
		System.out.println("Choose Song to play");
		displayAllSongs();
		int songNo=sc.nextInt();
		System.out.println(playlist.get(songNo-1).getName() +  "now Playing");
		
	}
	public static void shuffleSong() {
		displayAllSongs();
		int shuffle = sc.nextInt();
		System.out.println(playlist.get(shuffle-1).getName());
	}
	public static void editSong() {
		
	}

	
	
	
		
		
	
	
	 
}
